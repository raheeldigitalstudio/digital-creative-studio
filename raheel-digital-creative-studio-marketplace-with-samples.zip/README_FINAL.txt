RAHEEL DIGITAL CREATIVE STUDIO OFFICIAL — MARKETPLACE V4

This update adds:
1. Full-width desktop-first marketplace layout + mobile responsive layout.
2. Professional service catalog and five sample concepts per major service.
3. Sample -> Order flow.
4. Website order form with unique Order ID and browser demo queue.
5. WhatsApp order handoff.
6. Customer order queue and owner/admin queue (browser demo).
7. Creator/worker application form.
8. Creator wallet/earnings dashboard UI.
9. Referral/affiliate account concept.
10. Payment method selection: Easypaisa, JazzCash, Faysal Bank/Bank Transfer,
   international card gateway, PayPal/Binance where supported.
11. Original sample concepts generated for this site; not presented as third-party client work.

PRODUCTION BACKEND REQUIRED:
- User authentication + password reset
- Database for users/orders/workers
- Server-side order assignment and status updates
- Admin authentication and role permissions
- Payment gateway integration + webhooks
- Marketplace payouts/split payments and KYC/verification where required
- Creator commission calculation and payout ledger
- Email/WhatsApp/push notifications
- Secure file upload/storage
- Audit logs and fraud/risk controls

Do not put card numbers, API secrets, private wallet keys, or payment credentials in public HTML.


SAMPLE IMAGE UPDATE:
- Added 50 distinct local JPG sample images: 5 per service category.
- No remote image URLs are required, so the portfolio will not appear blank because an external image host blocked the request.
- Samples are original demo concepts generated for this website.

PAKISTAN PAYMENT UPDATE:
- Removed PayPal.
- Added Easypaisa, JazzCash, Raast, 1LINK/Bank Transfer, PayFast, NayaPay, SadaPay,
  UPaisa, HBL Konnect, Bank Account/IBAN, and Binance Pay with a merchant/compliance note.
- Live payment acceptance still requires your own verified merchant accounts and gateway credentials.
